<style type="text/css" media="all">

<?php if(of_get_option('webfolio_headingfontlink') != '' and of_get_option('webfolio_headingfontface') != '') { ?>
    h1,h2,h3,h4,h5,h6 {
    <?php echo of_get_option('webfolio_headingfontface');?>
    }
<?php } ?>
</style>