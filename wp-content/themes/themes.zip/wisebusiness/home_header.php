<div id="headerImg"><img src="<?php bloginfo('template_url'); ?>/images/sample_img_slider.png" alt="" /></div>
<div id="headerText">
	<img src="<?php bloginfo('template_url'); ?>/images/sample_title_slider.png" alt="" />
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore  lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore</p>
	<p><strong><a href="#">Read more &raquo;</a></strong></p>
</div>
<div id="buttons">
	<a href="#">Take the tour</a>
	<a href="#">Request a trial</a>
</div>

