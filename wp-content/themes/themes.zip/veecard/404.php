<?php get_header(); ?>

		<article>

  			<header>
				<h1><?php _e('404 Not Found','site5framework') ?></h1>
			</header>

			<p><?php _e("The article you were looking for was not found, but maybe try looking again!", "site5framework"); ?></p>

		</article>

<?php get_footer(); ?>