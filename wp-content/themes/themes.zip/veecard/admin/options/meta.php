<?php
    $options[] = array( "name" => "Meta",
    					"sicon" => "metatag.png",
						"type" => "heading");

    $options[] = array( "name" => "Meta Description",
						"id" => $shortname."_metadescription",
						"std" => "full functionable, premium resume wordpress theme solution for your website.",
						"type" => "textarea");

    $options[] = array( "name" => "Meta Keywords",
						"std" => "proffesional wordpress theme, flexible wordpress theme, wordpress all in one theme, premium wordpress theme ",
						"id" => $shortname."_metakeywords",
                        "type" => "textarea");

?>