<?php
    $options[] = array( "name" => "Contact",
    					"sicon" => "mail.png",
                        "type" => "heading");

	$options[] = array( "name" => "Contact E-Mail",
                        "id" => $shortname."_contact_email",
                        "std" => "info@yoursite.com",
                        "type" => "text");

?>