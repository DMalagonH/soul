<style type="text/css" media="all">

<?php if(of_get_option('boldy_heading_font_link') != '' and of_get_option('boldy_heading_font_family') != '') { ?>
    h1,h2,h3 {
    <?php echo of_get_option('boldy_heading_font_family');?>
    }
<?php } ?>
</style>