<style type="text/css" media="all">
    <?php echo of_get_option('boldy_css_code');?>
</style>